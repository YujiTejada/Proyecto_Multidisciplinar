package com.example.manualdemo

data class Temario (val Image: Int, val name: String)